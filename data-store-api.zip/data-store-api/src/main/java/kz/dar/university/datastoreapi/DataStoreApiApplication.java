package kz.dar.university.datastoreapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataStoreApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataStoreApiApplication.class, args);
	}

}
