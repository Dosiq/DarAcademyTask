package kz.dar.university.datastoreapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataStoreApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
