package kz.dar.university.eventdiscoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
