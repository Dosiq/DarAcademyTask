package kz.dar.university.eventdiscoveryserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventDiscoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventDiscoveryServerApplication.class, args);
	}

}
