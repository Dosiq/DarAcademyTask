package kz.dar.university.eventapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
