package kz.dar.university.eventapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventApiGatewayApplication.class, args);
	}

}
